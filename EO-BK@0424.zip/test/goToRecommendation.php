
<?php
 	require_once('Page.php');

	// the interface to change the page content to show recommendation
	$page = new Page('recommendation.php');
	echo $page;
?>