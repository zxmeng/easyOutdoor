<?php
// Define configuration
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PSW", "");
define("DB_NAME", "eo");

define("SITE_TITLE", "WLCOME TO EASYOUTDOOR");

?>