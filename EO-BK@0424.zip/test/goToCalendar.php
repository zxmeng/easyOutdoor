
<?php
	// the interface to change the page content to calendarSearch
 	require_once('Page.php');
	$page = new Page('calendarSearch.php');
	echo $page; // return to client
?>