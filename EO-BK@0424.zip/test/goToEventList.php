
<?php

	// the interface to change the page content to eventList
 	require_once('Page.php');
	$page = new Page('eventList.php');
	echo $page;
?>