<?php
// init.php
require_once('config.php');
require_once('EventClass.php');
require_once('DBClass.php');
require_once('commentClass.php');
?>