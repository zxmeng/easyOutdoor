Before using our project, please first establish a database according to DB.sql.
And there are some record in demo.sql for demonstration. You can insert those records into the database.

Because some functions in our project are concerned with time, if you find no events shown in the website, try to update the event date or create a new one.

Please change the configuration in cofig.php accordingly.
Please change the link url in Line 40 of register.php according to your own server address and the path of activate.php.

To browse our website, you can use the link "<your_server_address>/easyOutdoor".